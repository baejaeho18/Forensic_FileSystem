## 00.cmake
 - basic
 - tut 

## 01.line (설명)
 - line.cpp: getline을 이용한 text file I/O
 - line.rb: ruby version

## 02.bin.write (설명)
 - file.binary.cpp : endian test

## 03.bin.read/seek/tell (연습)
 - 앞 30 byte를 건너띄고 4 byte big endian 10개, 4byte little 10개의 숫자 읽고 합 구하기

## 10.buffer (연습)
 - 앞 30 byte를 건너띄고 4 byte big endian 10개, 4byte little 10개의 숫자 읽고 합 구하기


## 객체 지향 설계

## fat32
 - boot.record
 - cluster.table
 - dir.entry
 - lfn.entry (과제)

 - node / node_stream (가장 중요)
 - fat32 / 

## tdd
 - pascal의 삼각형 TDD로 개발하기
