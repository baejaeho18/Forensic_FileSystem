#include <iostream>

#include "add.h"
#include "sub.h"

using namespace std;

int main()
{
    cout << add(1, 2) << endl;
    cout << sub(2, 1) << endl;

    return 0;
}
