

## What I learned
* cmake를 이용한 conditional build
* library 만들고 링크하기

## Link
1. [tuwlab 링크](https://tuwlab.com/27260)
2. [cmake 공식 링크](https://cmake.org/cmake-tutorial/)

