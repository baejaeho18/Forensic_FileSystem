
  auto DirectoryEntry::from_fat_time(uint16_t date, uint16_t time) -> TimeStamp
  {
    if (date == 0 and time == 0)
      return TimeStamp::min_value();
    
    auto yr = 1980 + ((date & 0xFE00) >> 9);
    auto mt = (date & 0x01E0) >> 5;
    auto dy =  date & 0x001F;
    auto hr = (time & 0xF800) >> 11;
    auto mn = (time & 0x07E0) >> 5;
    auto sc = (time & 0x001F) * 2;
    
    try
    {
      if (yr < 0)
        return TimeStamp::min_value();
      
      if (mt < 1 || mt > 12 || dy < 1 || dy > 31)
        return TimeStamp::min_value();
      
      if (hr < 0 || hr > 23)
        return TimeStamp::min_value();
      
      if (mn < 0 || mn > 59)
        return TimeStamp::min_value();
      
      if (sc < 0 || sc > 59)
        return TimeStamp::min_value();
    }
    catch (...)
    {
    }
    
    return TimeStamp(yr, mt, dy, hr, mn, sc, 0);
  }
