#include "catch2/catch.hpp"
#include "add.h"

TEST_CASE("Add Test Case") {

  SECTION("") {
    REQUIRE(add(1, 1) == 2);
  }
}
