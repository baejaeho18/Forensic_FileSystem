#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cctype>

using namespace std;

int to_be(char* bytes)
{
    return ((int)bytes[0] << 24) | ((int)bytes[1] << 16) |
           ((int)bytes[2] <<  8) | ((int)bytes[3] <<  0);
}

int to_le(char* bytes)
{
    return *(int *)(char *)bytes;
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        cout << "usage a.out filename\n";
        return EXIT_FAILURE;
    }

    ifstream ifs;
    ifs.open(argv[1], ios_base::binary);

    if (!ifs.is_open())
    {
        cout << "error\n";
        return EXIT_FAILURE;
    }

    char buff[4] = { 0 };
    ifs.seekg(30, ios_base::beg);

    cout << hex;
    for (int i=0; i<10; i++)
    {
        ifs.read(buff, 4);
        auto res = to_be(buff);
        cout << res << " ";
    }

    for (int i=0; i<10; i++)
    {
        ifs.read(buff, 4);
        auto res = to_le(buff);
        cout << res << " ";
    }

    return 0;
}